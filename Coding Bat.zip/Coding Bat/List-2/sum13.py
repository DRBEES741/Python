"""
Return the sum of the numbers in the array, returning 0 
for an empty array. Except the number 13 is very unlucky, 
so it does not count and numbers that come immediately after 
a 13 also do not count.

sum13([1, 2, 2, 1]) → 6
sum13([1, 1]) → 2
sum13([1, 2, 2, 1, 13]) → 6
"""

def sum13(nums):
  	sum = 0
  	counting = True
  	count = 0
  	if len(nums) == 0:
    	return 0
  	for num in nums:
    	if num == 13:
      		count = 0
      		counting = False
    	if not counting:
      		count += 1
    	if count == 3:
      		count = 0
      		counting = True
    	if counting:
      		sum += num
  	return sum